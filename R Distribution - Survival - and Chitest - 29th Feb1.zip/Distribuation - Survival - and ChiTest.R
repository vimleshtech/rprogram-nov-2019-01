
x <- seq(-10,10,by=.1)
mean(x)
sd(x)


y  = dnorm(x,mean=2.5, sd=.5)


plot(x,y)


#pnorm
y <- pnorm(x, mean = 2.5, sd = 2)
plot(x,y)

#qnorm
y <- qnorm(x, mean = 2, sd = 1)
plot(x,y)


###
install.packages("survival")

library("survival")

#Surv(time,event)
#survfit(formula)

pbc
str(pbc)

head(pbc)

Surv(pbc$time,pbc$status == 2)

y = survfit(Surv(pbc$time,pbc$status == 2)~1)



plot(y)



##
library("MASS")
print(str(Cars93))

car.data <- data.frame(Cars93$AirBags, Cars93$Type)

car.data = table(Cars93$AirBags, Cars93$Type) 




print(chisq.test(car.data))
