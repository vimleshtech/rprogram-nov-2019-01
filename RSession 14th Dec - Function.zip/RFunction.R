
#
a = c(33,44,55,-44,55,-88,55)
b= c()
c =c()

for(x in a){
  
  if(x<0){
      #print("negative")
    b = append(b,x)
    
  }else{
    
    print("positive")
    c = append(c,x)
  }
}

a = append(b,c)


#function 
#i. No argument no return
wel <- function(){
    print("welcome to function world....!! this code can be reused")
  
}
#ii. No argument with return
getNum <- function(){
 
  a =55
  c =55
  return(100)
  
}
#iii. Argument with return 
addNum <- function(a,b){
  
  c = a+b
  print(c)
}
#iv. Argument with no return 
subNum <- function(a,b){
  c = a-b
  return(c)
}

#v. Recussive function  : function which invoke inself that function is called recussive function 
fact <- function(n){
  
  if(n==1){
    return(n)
  }else{
    
    return(n*fact(n-1))
  }
}

wel()

o = getNum()

addNum(11,33)
addNum(114,33)


o = subNum(11,3)
o
addNum(o,100)

s = fact(5)
print(s)
