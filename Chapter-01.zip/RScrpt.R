#addition of two numbers 
a =11
b =44
c =a+b

c

############################
letters

#############################
LETTERS

#
month.name

#
a =444
is.numeric(a) #return boolean if type is numeric 
typeof(a)


name ="nitin"
is.character(name)
is.numeric(name)

typeof(name)



###
a <- "11"
b <- "10"

a = as.numeric(a)
b = as.numeric(b)
c = a+b
c 


#Conditional statement
#wap to take input in 5 subjects and print total, avg, and grade 
hs <- 67
es <- 77
cs <- 87
ms <- 13
ss <- 12

total = hs+es+cs+ms+ss
avg = total/5
print(total)
print(avg)

if(avg>80){
  
  print("A")
}else if(avg>60 && avg<80) {
  
  print("B")
}else{
  
  print("C")
}
####################
a=5000
a=as.numeric(a)
b= a*.10

b

c=10000
c=as.numeric(b)
d= b*.10

hra=a-b *.10
print(hra)
if(a>5000){
  print ("a")
  }else if(a>5000 && c<10000)
    print("c")
    

d=10001
d=as.numeric(d)
e=d*.15

f=15000
f=as.numeric(f)
g=f*.15

hra=d-e*.15
print(hra)
if(d>10001){
  print("d")
}else if(d>10001 && f<15000)
  print(g)

a=5000
a=as.numeric(a)
b= a*.05

b

c=10000
c=as.numeric(b)
d= b*.05

da=a-b*.05
print(hra)
if(a>5000){
  print ("a")
}else if(a>5000 && c<10000)
  print("c")

d=10001
d=as.numeric(d)
e=d*.08

f=15000
f=as.numeric(f)
g=f*.08

da=d-f*.08
print(da)
if(d>10001){
  print("d")
}else if(d>10001 && f<15000)
  print(g)


####################
a=60
a=as.numeric(a)
b=59
b=as.numeric(b)
c=50
c=as.numeric(c)
d=49
d=as.numeric(d)
e=40
e=as.numeric(e)
f=40
f=as.numeric(f)
g=first
g=as.character(g)
h=second
h=as.character(h)
i=third
i=as.character(i)
j=fail
j=as.character(j)
print("A")
if(a>60){
  
  print("g")
}else if (a>60 && b<59){
  print(h)
  
}
  
print("C")
if(b<59){
  
  print("h")
}else if (b<59 && c>50){
  
  print(i)
}
  
print("d")
if(d<49){
  
  print("e")
} else if (d<49 && e>40) {
  
  print(i)
}

print(f)
if(f<40){
  
  print("j")
  
} 






